(function () {
  'use strict';

  // YouTube-specific logic

  const extractCaptionTracks = () => {
    try {
      const pr = window.ytInitialPlayerResponse;
      let tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks || null;

      if (!tracks) {
        const ytdPlayer = document.querySelector('ytd-player');
        const player = ytdPlayer?.getPlayer?.() || ytdPlayer?.player;
        const resp = player?.getPlayerResponse?.() || null;
        tracks = resp?.captions?.playerCaptionsTracklistRenderer?.captionTracks || null;
      }

      const videoId = new URL(location.href).searchParams.get('v') ||
                      pr?.videoDetails?.videoId || null;

      // Debug: log extracted track URLs (full baseUrl + diagnostics)
      if (tracks?.length) {
        console.log('[ytxt] Extracted tracks:', tracks.map(t => {
          const s = String(t.baseUrl || '');
          return {
            lang: t.languageCode,
            kind: t.kind,
            vssId: t.vssId || t.vss_id,
            hasParamsProp: !!t.params,
            paramsLen: t.params ? String(t.params).length : 0,
            keys: Object.keys(t || {}).slice(0, 12),
            hasLangParam: /[?&]lang=/.test(s),
            hasFmtParam: /[?&]fmt=/.test(s),
            urlLen: s.length,
            head: s.slice(0, 140),
            tail: s.slice(-140)
          };
        }));
      }

      return { tracks, videoId };
    } catch (e) {
      return { tracks: null, videoId: null, error: String(e) };
    }
  };

  const pickBestTrack = (tracks) => {
    if (!tracks?.length) return null;
    const lang = (navigator.language || 'en').split('-')[0];
    return tracks.find(t => t.languageCode === lang && t.kind !== 'asr') ||
           tracks.find(t => t.languageCode === lang) ||
           tracks.find(t => t.languageCode?.startsWith('en') && t.kind !== 'asr') ||
           tracks[0];
  };

  // Harvest successful transcript requests made by the YouTube page itself
  // Stores per-video templates for:
  // - YouTubeI get_transcript (preferred)
  // - timedtext with pot/potc (+ device hints)

  const store = new Map(); // videoId -> { yti?: { params }, tt?: { byKey: Map<string, Entry> } }

  const keyForTrack = (track) => {
    const lang = track?.languageCode || '';
    const kind = track?.kind || '';
    return `${lang}|${kind || 'manual'}`;
  };

  const onHarvestEvent = (detail) => {
    try {
      const { kind, url, params = {}, videoId, contentType = '', size = 0, body = '' } = detail || {};
      if (!videoId && params && typeof params.v === 'string') {
        // derive v from query if not provided
        detail.videoId = params.v;
      }
      const vid = detail.videoId;
      if (!vid) return;
      const bucket = store.get(vid) || { tt: { byKey: new Map() } };

      if (kind === 'youtubei') {
        // Capture params token if present in body (response body not useful here)
        // The injected observer sends request body params if available via detail.reqParams
        const p = detail.reqParams || null;
        if (p) bucket.yti = { params: p };
        store.set(vid, bucket);
        return;
      }

      if (kind === 'timedtext') {
        if (!url || !body || size <= 0) return;
        // Try to derive track key from lang/kind query params
        const lang = params.lang || null;
        const isAsr = params.kind === 'asr' || (params.cc && /^a\./.test(params.cc));
        const ttKey = `${lang || ''}|${isAsr ? 'asr' : 'manual'}`;
        bucket.tt.byKey.set(ttKey, { url, params, contentType, size, body });
        store.set(vid, bucket);
        return;
      }
    } catch {
      // ignore
    }
  };

  const wait = (ms) => new Promise(res => setTimeout(res, ms));

  // Try to gently cause the page to fetch subtitles for the given track
  const nudgeForTrack = async (track) => {
    try {
      const ytdPlayer = document.querySelector('ytd-player');
      const player = ytdPlayer?.getPlayer?.() || ytdPlayer?.player;
      const ccBtn = document.querySelector('.ytp-subtitles-button');

      // Prefer using player API if available
      if (player?.setOption) {
        try {
          player.setOption('captions', 'track', {
            languageCode: track?.languageCode || 'en',
            kind: track?.kind === 'asr' ? 'asr' : undefined
          });
          // Enable captions briefly
          player.setOption('captions', 'enabled', true);
        } catch {}
      } else if (ccBtn) {
        // Toggle CC button to trigger a timedtext fetch
        const wasPressed = ccBtn.getAttribute('aria-pressed') === 'true';
        ccBtn.click();
        // restore after a short delay if we changed it
        setTimeout(() => {
          try {
            const pressed = ccBtn.getAttribute('aria-pressed') === 'true';
            if (pressed !== wasPressed) ccBtn.click();
          } catch {}
        }, 1200);
      }
    } catch {}
  };

  const awaitTemplateForTrack = async (videoId, track, timeoutMs = 2500) => {
    const existing = store.get(videoId);
    const tKey = keyForTrack(track);
    if (existing?.yti?.params) return { kind: 'youtubei', data: existing.yti };
    const ttEntry = existing?.tt?.byKey?.get(tKey) || null;
    if (ttEntry) return { kind: 'timedtext', data: ttEntry };

    let done = false;
    let result = null;
    const onEvent = (e) => {
      try {
        const d = e?.detail || {};
        if (!d) return;
        if (d.kind === 'youtubei') {
          if (d.videoId === videoId && d.reqParams) {
            onHarvestEvent(d);
            result = { kind: 'youtubei', data: { params: d.reqParams } };
            done = true;
          }
          return;
        }
        if (d.kind === 'timedtext') {
          if (d.videoId === videoId) {
            onHarvestEvent(d);
            // try match on language
            const lang = d.params?.lang || null;
            const isAsr = d.params?.kind === 'asr' || (d.params?.cc && /^a\./.test(d.params.cc));
            const key = `${lang || ''}|${isAsr ? 'asr' : 'manual'}`;
            if (key === tKey && d.body && d.body.length > 0) {
              result = { kind: 'timedtext', data: d };
              done = true;
            }
          }
        }
      } catch {}
    };

    window.addEventListener('ytxt:transcript-template', onEvent);
    try {
      // Trigger page to fetch captions for this track
      nudgeForTrack(track);
      const start = Date.now();
      while (!done && Date.now() - start < timeoutMs) {
        await wait(120);
      }
    } finally {
      window.removeEventListener('ytxt:transcript-template', onEvent);
    }
    return result;
  };

  // Injection helper to install page-context observer
  const injectObserver = () => {
    try {
      if (window.__ytxtObserverInjected) return;
      window.__ytxtObserverInjected = true;
      const s = document.createElement('script');
      s.type = 'text/javascript';
      s.textContent = `(() => { try {
      if (window.__ytxtObserverInstalled) return; window.__ytxtObserverInstalled = true;
      const toURL = (u) => { try { return new URL(u, location.origin); } catch { return null; } };
      const post = (d) => { try { window.dispatchEvent(new CustomEvent('ytxt:transcript-template', { detail: d })); } catch {} };
      const harvest = async (reqUrl, res, reqBody, headers) => {
        try {
          const u = toURL(String(reqUrl||'')); if (!u) return;
          const path = u.pathname || '';
          const isTT = path.includes('/api/timedtext');
          const isYTI = path.includes('/youtubei/') && path.includes('/get_transcript');
          if (!isTT && !isYTI) return;
          const clone = (res && res.clone) ? res.clone() : res;
          if (!clone || !clone.text) return;
          const text = await clone.text();
          if (!text || text.length === 0) return;
          const ct = (res && res.headers && res.headers.get && res.headers.get('content-type')) || '';
          const params = {}; if (u && u.searchParams) { u.searchParams.forEach((v,k)=>{params[k]=v}) }
          const vid = params.v || null;
          if (isTT) {
            post({ kind:'timedtext', url: u.toString(), params, videoId: vid, contentType: ct, size: text.length, body: text });
          } else if (isYTI) {
            let reqParams = null;
            if (reqBody && typeof reqBody === 'string') {
              try { const j = JSON.parse(reqBody); if (j && j.params) reqParams = j.params; } catch {}
            }
            post({ kind:'youtubei', url: u.toString(), videoId: vid, contentType: ct, size: text.length, body: text, reqParams });
          }
        } catch {}
      };
      const of = window.fetch.bind(window);
      window.fetch = function(input, init) {
        let body = init && init.body ? init.body : null;
        if (body && typeof body !== 'string') {
          try { body = JSON.stringify(body); } catch {}
        }
        const p = of(input, init);
        p.then(res => { try { harvest(input, res, body, (init && init.headers) || {}); } catch {} });
        return p;
      };
      const xo = XMLHttpRequest.prototype.open; const xs = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function(m,u,...r){ this.__ytxt = { m, u }; return xo.call(this,m,u,...r) };
      XMLHttpRequest.prototype.send = function(b){ const that=this; this.addEventListener('load', function(){ try{
        const info = that.__ytxt||{}; const url=info.u||''; const res={ headers: { get: (k)=> that.getResponseHeader(k) } };
        const fakeRes = { clone: ()=>({ text: async()=> (typeof that.responseText==='string'?that.responseText:'') }), headers: { get: (k)=> that.getResponseHeader(k) } };
        const reqBody = (typeof b==='string')? b : null; harvest(url, fakeRes, reqBody, {});
      }catch{} }); return xs.call(this,b) };
    } catch(e) {} })();`;
      (document.head || document.documentElement).appendChild(s);
      setTimeout(() => s.remove(), 0);
    } catch {}
  };

  // State management


  const state = {
    tracks: [],
    videoId: null,
    elements: null,
    isLoading: false,
    isCollapsed: false,
    debug: { via: '', meta: null }
  };

  const setStatus = (msg, kind = '') => {
    if (!state.elements) return;
    const { status } = state.elements;
    status.textContent = msg || '';
    status.className = 'ytxt-footnote ' + (kind ? `ytxt-${kind}` : '');
  };

  const setLoading = (isLoading) => {
    state.isLoading = isLoading;
    if (!state.elements) return;

    const { btnGet, spinner, btnText, sel, chkTS } = state.elements;
    btnGet.disabled = isLoading;
    sel.disabled = isLoading;
    chkTS.disabled = isLoading;
    spinner.style.display = isLoading ? 'inline-block' : 'none';
    btnText.style.display = isLoading ? 'none' : 'inline';
    btnGet.classList.toggle('ytxt-loading', isLoading);
  };

  const updateStats = (text) => {
    if (!state.elements) return;
    const lines = text.split('\n').length;
    const words = text.split(/\s+/).filter(Boolean).length;
    const chars = text.length;
    state.elements.stats.textContent = `${lines} lines · ${words} words · ${chars.toLocaleString()} chars`;
  };

  const updateTrackSelect = (tracks) => {
    if (!state.elements) return;
    const { sel, btnGet } = state.elements;

    // Clear all options using DOM methods (TrustedHTML-safe)
    while (sel.firstChild) {
      sel.removeChild(sel.firstChild);
    }

    if (!tracks?.length) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'No captions available';
      sel.appendChild(opt);
      sel.disabled = true;
      btnGet.disabled = true;
      return;
    }

    sel.disabled = false;
    btnGet.disabled = false;
    const best = pickBestTrack(tracks);

    tracks.forEach((t, i) => {
      const opt = document.createElement('option');
      opt.value = String(i);
      opt.textContent = (t.name?.simpleText || t.languageCode || `Track ${i + 1}`) +
                        (t.kind === 'asr' ? ' (auto)' : '') +
                        (t.languageCode ? ` [${t.languageCode}]` : '');
      opt.selected = t === best;
      sel.appendChild(opt);
    });
  };

  const reportStatus = (msg) => {
    try {
      if (!msg) return;
      window.dispatchEvent(new CustomEvent('ytxt:status', { detail: String(msg) }));
    } catch {}
  };

  // Generic utility functions

  const msToTimestamp = (ms) => {
    const totalSec = Math.floor(Math.max(0, Number(ms) || 0) / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return (h > 0 ? String(h).padStart(2, '0') + ':' : '') +
           String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  };

  const fetchCaption = async (url) => {
    // Fetch directly from MAIN world - we have access to YouTube's cookies here
    try {
      const res = await fetch(url, {
        credentials: 'include',
        // Use same-origin semantics; YouTube may reject CORS-mode requests
        mode: 'same-origin'
      });

      const contentType = res.headers.get('content-type') || 'unknown';

      // Collect response metadata for debugging
      const responseInfo = {
        status: res.status,
        statusText: res.statusText,
        redirected: res.redirected,
        type: res.type,
        url: res.url,
        contentType: contentType
      };

      // Try reading body, with arrayBuffer fallback if text is empty/unavailable
      let body = '';
      let textErr = null;
      try {
        body = await res.clone().text();
      } catch (e) {
        textErr = e;
      }

      if (!body || body.length === 0) {
        try {
          const ab = await res.clone().arrayBuffer();
          if (ab && ab.byteLength > 0) {
            // Attempt to decode using TextDecoder; default to utf-8
            const charsetMatch = /charset=([^;]+)/i.exec(contentType || '') || [];
            const charset = (charsetMatch[1] || 'utf-8').trim();
            try {
              const dec = new TextDecoder(charset);
              body = dec.decode(ab);
            } catch (_) {
              const dec = new TextDecoder('utf-8');
              body = dec.decode(ab);
            }
          }
        } catch (e) {
          // Ignore; will be handled below with headers/metadata
        }
      }

      if (!res.ok) {
        const headers = {};
        res.headers.forEach((value, key) => { headers[key] = value; });
        return {
          ok: false,
          error: `HTTP ${res.status}`,
          details: `Response: ${JSON.stringify(responseInfo)}\nHeaders: ${JSON.stringify(headers)}\nBody: ${String(body || '').substring(0, 500)}`
        };
      }

      if (!body || body.length === 0) {
        // Get headers for debugging
        const headers = {};
        res.headers.forEach((value, key) => {
          headers[key] = value;
        });

        // As a last resort, try XHR same-origin with credentials
        try {
          const { xhrBody, xhrType } = await new Promise((resolve, reject) => {
            try {
              const xhr = new XMLHttpRequest();
              xhr.open('GET', url, true);
              xhr.responseType = 'text';
              xhr.withCredentials = true;
              xhr.setRequestHeader('Accept', '*/*');
              xhr.onload = () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                  resolve({ xhrBody: xhr.responseText || '', xhrType: xhr.getResponseHeader('Content-Type') || '' });
                }
                else reject(new Error(`XHR status ${xhr.status}`));
              };
              xhr.onerror = () => reject(new Error('XHR network error'));
              xhr.send();
            } catch (e) { reject(e); }
          });

          if (xhrBody && xhrBody.length > 0) {
            const finalType = xhrType || contentType || '';
            return { ok: true, status: res.status, contentType: finalType, body: xhrBody };
          }
        } catch (e) {
          // fall through to error
        }

        return {
          ok: false,
          error: 'Empty response body',
          details: `Response info: ${JSON.stringify(responseInfo)}\nHeaders: ${JSON.stringify(headers)}\nRequested: ${url}`
        };
      }

      // Check if we got HTML when we expected JSON/VTT
      if (contentType.includes('text/html')) {
        return {
          ok: false,
          error: 'Got HTML instead of captions',
          details: `Received HTML page instead of caption data.\nResponse: ${JSON.stringify(responseInfo)}\nBody preview: ${body.substring(0, 500)}`
        };
      }

      return { ok: true, status: res.status, contentType, body };
    } catch (err) {
      return {
        ok: false,
        error: err.message || String(err),
        details: `Network error: ${err.message}\nURL: ${url.substring(0, 150)}`
      };
    }
  };

  // Fetch YouTubeI get_transcript JSON using the track's params
  const fetchYTTranscript = async (params) => {
    try {
      const ytcfg = window.ytcfg?.get ? window.ytcfg : null;
      const apiKey = ytcfg?.get?.('INNERTUBE_API_KEY') || null;
      const ctx = ytcfg?.get?.('INNERTUBE_CONTEXT') || null;
      const clientName = ytcfg?.get?.('INNERTUBE_CLIENT_NAME') || 'WEB';
      const clientVersion = ytcfg?.get?.('INNERTUBE_CLIENT_VERSION') || '2.20241007.00.00';
      if (!apiKey) {
        return { ok: false, error: 'Missing INNERTUBE_API_KEY' };
      }

      const body = {
        context: ctx || {
          client: {
            hl: (navigator.language || 'en').replace('_', '-'),
            gl: 'US',
            clientName,
            clientVersion
          }
        },
        params
      };

      const url = `/youtubei/v1/get_transcript?key=${encodeURIComponent(apiKey)}`;
      const res = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        mode: 'same-origin',
        headers: {
          'content-type': 'application/json',
          'x-youtube-client-name': String(clientName),
          'x-youtube-client-version': String(clientVersion)
        },
        body: JSON.stringify(body)
      });

      const contentType = res.headers.get('content-type') || '';
      const text = await res.text();
      if (!res.ok) {
        return { ok: false, error: `HTTP ${res.status}`, details: text.substring(0, 300) };
      }
      if (!text) {
        return { ok: false, error: 'Empty YouTubeI response' };
      }
      let json;
      try { json = JSON.parse(text); } catch (e) {
        return { ok: false, error: 'Invalid JSON from YouTubeI', details: text.substring(0, 200) };
      }
      return { ok: true, json, contentType };
    } catch (err) {
      return { ok: false, error: err.message || String(err) };
    }
  };

  // Transcript format parsers


  const json3ToText = (json, withTS) => {
    if (!json?.events) return '';
    return json.events
      .filter(ev => ev?.segs)
      .map(ev => {
        const text = ev.segs.map(s => s.utf8 || '').join('').replace(/\s*\n+\s*/g, ' ').trim();
        return text && (withTS ? `[${msToTimestamp(ev.tStartMs || 0)}] ${text}` : text);
      })
      .filter(Boolean)
      .join('\n');
  };

  const vttToText = (vtt, withTS) => {
    const lines = vtt.split(/\r?\n/);
    const out = [];
    let bucket = [], ts = null;
    const timeRe = /(\d{2}:)?\d{2}:\d{2}\.\d{3}\s*-->\s*/;

    for (const raw of lines) {
      const line = raw.trim();
      if (!line || line.startsWith('WEBVTT') || /^\d+$/.test(line)) {
        if (bucket.length) {
          out.push(withTS && ts ? `[${ts}] ${bucket.join(' ')}` : bucket.join(' '));
          bucket = [];
          ts = null;
        }
        continue;
      }
      if (timeRe.test(line)) {
        ts = line.split('-->')[0].trim().replace(/\.\d+$/, '');
        continue;
      }
      bucket.push(line);
    }
    if (bucket.length) out.push(withTS && ts ? `[${ts}] ${bucket.join(' ')}` : bucket.join(' '));
    return out.join('\n');
  };

  const xmlToText = (xmlString, withTS) => {
    try {
      const doc = new DOMParser().parseFromString(xmlString, 'text/xml');
      const nodes = Array.from(doc.getElementsByTagName('text'));
      return nodes
        .map(n => {
          const raw = (n.textContent || '').replace(/\s*\n+\s*/g, ' ').trim();
          if (!raw) return null;
          if (!withTS) return raw;
          // YouTube XML provides either `start` (in seconds) or `t` (in milliseconds)
          const startAttr = n.getAttribute('start');
          const tAttr = n.getAttribute('t');
          let startMs = 0;
          if (tAttr != null) {
            startMs = Number(tAttr) || 0; // already in ms
          } else if (startAttr != null) {
            startMs = (Number(startAttr) || 0) * 1000; // seconds -> ms
          }
          return `[${msToTimestamp(startMs)}] ${raw}`;
        })
        .filter(Boolean)
        .join('\n');
    } catch {
      return '';
    }
  };

  const parseTranscript = (body, contentType, withTS) => {
    if (contentType.includes('json')) {
      try {
        return json3ToText(JSON.parse(body), withTS);
      } catch {
        return '';
      }
    }
    if (contentType.includes('xml')) return xmlToText(body, withTS);
    return vttToText(body, withTS);
  };

  // --- YouTubeI get_transcript JSON parser ---------------------------------
  const getTextFromRuns = (runs) => (Array.isArray(runs) ? runs.map(r => r.text || '').join('') : '');

  const extractCueText = (cue) => {
    if (!cue) return '';
    if (typeof cue.simpleText === 'string') return cue.simpleText;
    if (Array.isArray(cue.runs)) return getTextFromRuns(cue.runs);
    return '';
  };

  const toMs = (txt) => {
    if (!txt) return 0;
    // Formats like 0:05, 01:02:03 etc. We keep seconds precision.
    const parts = String(txt).split(':').map(Number);
    let s = 0;
    if (parts.length === 3) s = parts[0] * 3600 + parts[1] * 60 + parts[2];
    else if (parts.length === 2) s = parts[0] * 60 + parts[1];
    else s = parts[0] || 0;
    return Math.round(s * 1000);
  };

  const parseYouTubeITranscript = (data, withTS) => {
    try {
      if (!data) return '';
      // Traverse to find any cue groups
      const groups = [];
      const stack = [data];
      while (stack.length) {
        const node = stack.pop();
        if (!node) continue;
        if (Array.isArray(node)) { stack.push(...node); continue; }
        if (typeof node === 'object') {
          if (node.transcriptCueGroupRenderer) {
            groups.push(node.transcriptCueGroupRenderer);
          }
          for (const k in node) stack.push(node[k]);
        }
      }
      if (!groups.length) return '';

      const lines = [];
      for (const g of groups) {
        const cueR = g.cue?.transcriptCueRenderer || g.transcriptCueRenderer || null;
        const cueObj = cueR || g.cue;
        const text = extractCueText(cueObj?.cue || cueObj?.text || cueObj);
        if (!text) continue;
        if (withTS) {
          const ts = cueObj?.startTimeText?.simpleText || g.formattedStartTime?.simpleText || null;
          const ms = ts ? toMs(ts) : Number(cueObj?.startOffsetMs) || 0;
          lines.push(`[${msToTimestamp(ms)}] ${text}`);
        } else {
          lines.push(text);
        }
      }
      return lines.join('\n');
    } catch {
      return '';
    }
  };

  const tryYouTubeI = async (track, videoId, withTS) => {
    try {
      // Prefer harvested params first
      const harvested = await awaitTemplateForTrack(videoId, track, 1800);
      if (harvested?.kind === 'youtubei' && harvested.data?.params) {
        reportStatus('Using harvested YouTubeI params…');
        const resp = await fetchYTTranscript(harvested.data.params);
        if (resp?.ok) {
          const text = parseYouTubeITranscript(resp.json, withTS);
          if (text?.trim()) return { ok: true, text, via: 'youtubei:harvest', meta: { endpoint: 'youtubei', contentType: resp.contentType || 'application/json' } };
        }
      }
    } catch {}

    try {
      // Fallback: track-provided params (if present)
      if (track?.params) {
        reportStatus('Trying YouTubeI (track params)…');
        const resp = await fetchYTTranscript(track.params);
        if (resp?.ok) {
          const text = parseYouTubeITranscript(resp.json, withTS);
          if (text?.trim()) return { ok: true, text, via: 'youtubei:track-params', meta: { endpoint: 'youtubei', contentType: resp.contentType || 'application/json' } };
        }
      }
    } catch {}
    return { ok: false };
  };

  const waitForEl = (sel, timeout = 2000) => new Promise((resolve) => {
    const el = document.querySelector(sel);
    if (el) return resolve(el);
    const mo = new MutationObserver(() => {
      const e = document.querySelector(sel);
      if (e) { mo.disconnect(); resolve(e); }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => { try { mo.disconnect(); } catch {} resolve(null); }, timeout);
  });

  const openTranscriptPanel = async () => {
    // Try built-in menu path: find menu button → click "Show transcript"
    try {
      const menu = document.querySelector('ytd-menu-renderer #button') || document.querySelector('#button[aria-label*="More actions" i]');
      if (menu) {
        menu.click();
        // Wait for popup items
        const popup = await waitForEl('ytd-menu-popup-renderer', 1500);
        if (popup) {
          const item = Array.from(popup.querySelectorAll('ytd-menu-service-item-renderer, tp-yt-paper-item'))
            .find(n => /transcript/i.test(n.textContent || ''));
          if (item) {
            item.click();
            // Wait for transcript panel to appear
            await waitForEl('ytd-transcript-renderer,ytd-transcript-panel-renderer', 2000);
          }
        }
      }
    } catch {}
  };

  const scrapeTranscript = (withTS) => {
    try {
      // Prefer the transcript panel renderer when available
      const panel = document.querySelector('ytd-transcript-renderer,ytd-transcript-panel-renderer');
      if (!panel) return '';
      const segments = panel.querySelectorAll('ytd-transcript-segment-renderer');
      const out = [];
      for (const seg of segments) {
        const t = seg.querySelector('.segment-start, yt-formatted-string.segment-start') || seg.querySelector('yt-formatted-string[aria-label*=\":\"]');
        const textNode = seg.querySelector('.segment-text, yt-formatted-string.segment-text') || seg.querySelector('yt-formatted-string[dir]');
        const text = (textNode?.textContent || '').replace(/\s+/g, ' ').trim();
        if (!text) continue;
        if (withTS) {
          const ts = (t?.textContent || '').trim();
          out.push(ts ? `[${ts}] ${text}` : text);
        } else {
          out.push(text);
        }
      }
      return { text: out.join('\n'), count: segments.length };
    } catch { return ''; }
  };

  const tryDomPanel = async (_track, _videoId, withTS) => {
    try {
      // If already open, scrape directly
      let first = scrapeTranscript(withTS);
      let text = typeof first === 'string' ? first : (first?.text || '');
      const count = typeof first === 'object' && first ? first.count : undefined;
      if (text?.trim()) {
        reportStatus('Loaded via transcript panel');
        return { ok: true, text, via: 'dom:panel', meta: { endpoint: 'dom-panel', segments: count, lines: (text.split('\n')||[]).length } };
      }
      // Try to open the panel quietly and scrape
      reportStatus('Opening transcript panel…');
      await openTranscriptPanel();
      const second = scrapeTranscript(withTS);
      text = typeof second === 'string' ? second : (second?.text || '');
      const count2 = typeof second === 'object' && second ? second.count : undefined;
      if (text?.trim()) {
        reportStatus('Loaded via transcript panel');
        return { ok: true, text, via: 'dom:panel', meta: { endpoint: 'dom-panel', segments: count2, lines: (text.split('\n')||[]).length } };
      }
    } catch {}
    return { ok: false };
  };

  const tryTimedtextHarvest = async (track, videoId, withTS) => {
    try {
      const harvested = await awaitTemplateForTrack(videoId, track, 1800);
      if (harvested?.kind === 'timedtext' && harvested.data?.body) {
        reportStatus('Using harvested timedtext response…');
        const ct = harvested.data.contentType || '';
        const text = parseTranscript(harvested.data.body, ct, withTS);
        if (text?.trim()) return { ok: true, text, via: 'timedtext:harvest', meta: { endpoint: 'timedtext', url: harvested.data.url, contentType: ct, size: harvested.data.size || harvested.data.body.length } };
      }
    } catch {}
    return { ok: false };
  };

  const buildFallbackUrl = (track, videoId, fmt) => {
    try {
      const t = track || {}; if (!videoId) return null;
      let lang = t.languageCode || null; let kind = t.kind || null;
      const vss = t.vssId || t.vss_id || null;
      if (!lang && typeof vss === 'string') {
        if (vss.startsWith('a.')) { lang = vss.slice(2); kind = 'asr'; }
        else if (vss.startsWith('.')) { lang = vss.slice(1); }
      }
      if (!lang) return null;
      const params = new URLSearchParams();
      params.set('v', videoId);
      params.set('lang', lang);
      if (kind === 'asr') { params.set('caps', 'asr'); params.set('kind', 'asr'); }
      const name = t?.name?.simpleText || (Array.isArray(t?.name?.runs) ? t.name.runs.map(r => r.text).join('') : null);
      if (name && kind !== 'asr') params.set('name', name);
      if (fmt) params.set('fmt', fmt);
      const uiLang = (navigator.language || 'en').replace('_', '-'); params.set('hl', uiLang);
      return `https://www.youtube.com/api/timedtext?${params.toString()}`;
    } catch { return null; }
  };

  const tryTimedtextDirect = async (track, videoId, withTS) => {
    const formats = [ { label:'raw', fmt:null }, { label:'json3', fmt:'json3' }, { label:'srv3', fmt:'srv3' }, { label:'vtt', fmt:'vtt' } ];
    for (const { label, fmt } of formats) {
      try {
        let urlStr = track.baseUrl;
        if (fmt) {
          const hasFmt = /([?&])fmt=/.test(urlStr);
          if (hasFmt) urlStr = urlStr.replace(/([?&])fmt=[^&#]*/g, `$1fmt=${encodeURIComponent(fmt)}`);
          else urlStr = urlStr + (urlStr.includes('?') ? '&' : '?') + `fmt=${encodeURIComponent(fmt)}`;
          if (fmt === 'srv3') {
            for (const kv of ['xorb=2','xobt=3','xovt=3']) {
              const [k] = kv.split('='); if (!new RegExp(`([?&])${k}=`).test(urlStr)) urlStr = urlStr + (urlStr.includes('?') ? '&' : '?') + kv;
            }
          }
        }
        const candidates = [urlStr];
        const fb = buildFallbackUrl(track, videoId, fmt || (label==='raw'?null:undefined));
        if (fb) candidates.push(fb);

        for (const c of candidates) {
          reportStatus(`Trying ${label}${c!==urlStr?' (fallback)':''}…`);
          const resp = await fetchCaption(c);
          if (!resp?.ok) continue;
          const text = parseTranscript(resp.body, resp.contentType||'', withTS);
          if (text?.trim()) return { ok: true, text, via: `timedtext:${label}${c!==urlStr?'-fb':''}`, meta: { endpoint: 'timedtext', url: c, contentType: resp.contentType || '', size: (resp.body || '').length } };
        }
      } catch {}
    }
    return { ok: false };
  };

  const fetchTranscript = async (track, videoId, withTS) => {
    // Strategy order: YouTubeI → DOM panel → harvested timedtext → direct timedtext
    const steps = [
      { name: 'YouTubeI', fn: tryYouTubeI },
      { name: 'DOM panel', fn: tryDomPanel },
      { name: 'Timedtext (harvest)', fn: tryTimedtextHarvest },
      { name: 'Timedtext (direct)', fn: tryTimedtextDirect }
    ];

    for (const step of steps) {
      try {
        const res = await step.fn(track, videoId, withTS);
        if (res?.ok && res.text?.trim()) {
          reportStatus(`Loaded via ${res.via || step.name}`);
          try {
            const meta = res.meta || {};
            window.dispatchEvent(new CustomEvent('ytxt:debug', { detail: { via: res.via || step.name, meta } }));
          } catch {}
          return res.text;
        }
      } catch {}
    }
    throw new Error('Transcript not available via YouTubeI, panel, or timedtext');
  };

  // Event handlers and actions


  // Check if an ad is currently playing
  const isAdPlaying$1 = () => {
    const player = document.querySelector('.html5-video-player');
    return player?.classList.contains('ad-showing') || false;
  };

  // Wait for ad to finish with timeout
  const waitForAdToFinish = (maxWaitMs = 30000) => {
    return new Promise((resolve) => {
      if (!isAdPlaying$1()) {
        resolve(true);
        return;
      }

      const startTime = Date.now();
      const checkInterval = setInterval(() => {
        if (!isAdPlaying$1()) {
          clearInterval(checkInterval);
          resolve(true);
        } else if (Date.now() - startTime > maxWaitMs) {
          clearInterval(checkInterval);
          resolve(false); // Timed out
        }
      }, 500);
    });
  };
  // Live status updates from fetcher (MAIN world)
  window.addEventListener('ytxt:status', (e) => {
    try {
      const msg = e?.detail || '';
      if (!msg) return;
      if (!state.elements) return;
      setStatus(String(msg));
    } catch {}
  });

  // Capture debug meta and show in the panel's Debug section
  window.addEventListener('ytxt:debug', (e) => {
    try {
      const info = e?.detail || {};
      state.debug = { via: info.via || '', meta: info.meta || null };
      const pre = state.elements?.container?.querySelector('#ytxt-debug-pre');
      if (pre) {
        const meta = info.meta || {};
        const safe = { via: info.via || '', meta: { ...meta, url: meta.url ? String(meta.url).slice(0, 220) : undefined } };
        pre.textContent = JSON.stringify(safe, null, 2);
      }
    } catch {}
  });

  const handleFetch = async () => {
    try {
      if (!state.elements) return;

      // Check if ad is playing
      if (isAdPlaying$1()) {
        setLoading(true);
        setStatus('Waiting for ad to finish...');
        const adFinished = await waitForAdToFinish(30000);
        if (!adFinished) {
          setStatus('Ad still playing. Try again after the ad.', 'warn');
          setLoading(false);
          return;
        }
        // Small delay after ad ends for player data to update
        await new Promise(r => setTimeout(r, 1000));
        setStatus('Ad finished. Fetching transcript...');
      }

      if (!state.tracks?.length) {
        setStatus('No captions available for this video.', 'warn');
        return;
      }

      const idx = parseInt(state.elements.sel.value, 10);
      if (Number.isNaN(idx) || !state.tracks[idx]) {
        setStatus('Please select a caption track.', 'warn');
        return;
      }

      const track = state.tracks[idx];
      setLoading(true);
      setStatus('Fetching transcript...');

      const text = await fetchTranscript(track, state.videoId, state.elements.chkTS.checked);

      // Reveal output only after successful fetch
      if (state.elements.outputWrapper) state.elements.outputWrapper.style.display = '';
      state.elements.output.value = text;
      updateStats(text);
      setStatus(`Loaded from ${track.languageCode}${track.kind === 'asr' ? ' (auto)' : ''}`, 'ok');

      // Trigger view update (chips view will re-render)
      window.dispatchEvent(new CustomEvent('ytxt:transcript-loaded', { detail: { text } }));

      // Add success animation
      state.elements.output.classList.add('ytxt-success-flash');
      setTimeout(() => state.elements.output?.classList.remove('ytxt-success-flash'), 600);
      // Uncollapse if collapsed
      if (state.isCollapsed) {
        state.isCollapsed = false;
        state.elements.container.classList.toggle('ytxt-collapsed', false);
      }
    } catch (err) {
      console.error(err);
      // Show more helpful error messages
      const errorMsg = err.message || 'Unknown error';
      if (errorMsg.includes('not available')) {
        setStatus('Failed to load transcript. Try again or check if captions exist.', 'error');
      } else {
        setStatus(errorMsg, 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    try {
      if (!state.elements) return;

      const text = state.elements.output.value || '';
      if (!text) {
        setStatus('Nothing to copy', 'warn');
        return;
      }
      await navigator.clipboard.writeText(text);
      setStatus('✓ Copied to clipboard', 'ok');

      // Visual feedback
      const btn = state.elements.container.querySelector('[data-action="copy"]');
      btn?.classList.add('ytxt-success');
      setTimeout(() => btn?.classList.remove('ytxt-success'), 1000);
    } catch (err) {
      console.error(err);
      setStatus('Copy failed. Use Ctrl/Cmd+C', 'warn');
    }
  };

  const handleCopyPlain = async () => {
    try {
      if (!state.elements) return;

      const text = state.elements.output.value || '';
      if (!text) {
        setStatus('Nothing to copy', 'warn');
        return;
      }

      // Remove timestamps: lines starting with [00:00:00] or similar
      const plainText = text
        .split('\n')
        .map(line => line.replace(/^\[\d{1,2}:\d{2}:\d{2}\]\s*/, ''))
        .join('\n');

      await navigator.clipboard.writeText(plainText);
      setStatus('✓ Copied without timestamps', 'ok');

      // Visual feedback
      const btn = state.elements.container.querySelector('[data-action="copy-plain"]');
      btn?.classList.add('ytxt-success');
      setTimeout(() => btn?.classList.remove('ytxt-success'), 1000);
    } catch (err) {
      console.error(err);
      setStatus('Copy failed. Use Ctrl/Cmd+C', 'warn');
    }
  };

  const handleDownload = () => {
    if (!state.elements) return;

    const text = state.elements.output.value || '';
    if (!text) {
      setStatus('Nothing to download', 'warn');
      return;
    }
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `youtube-${state.videoId || 'transcript'}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    setStatus('✓ Downloaded as .txt', 'ok');
  };

  const handleCopyFiltered = async () => {
    try {
      if (!state.elements) return;

      const query = state.elements.searchInput?.value?.trim();
      if (!query) {
        setStatus('No active search filter', 'warn');
        return;
      }

      const text = state.elements.output.value || '';
      if (!text) {
        setStatus('Nothing to copy', 'warn');
        return;
      }

      // Get only matching lines
      const queryLower = query.toLowerCase();
      const lines = text.split('\n');
      const matches = lines.filter(line => line.toLowerCase().includes(queryLower));

      if (matches.length === 0) {
        setStatus('No matches to copy', 'warn');
        return;
      }

      const filteredText = matches.join('\n');
      await navigator.clipboard.writeText(filteredText);
      setStatus(`✓ Copied ${matches.length} filtered line${matches.length !== 1 ? 's' : ''}`, 'ok');

      // Visual feedback
      const btn = state.elements.container.querySelector('[data-action="copy-filtered"]');
      btn?.classList.add('ytxt-success');
      setTimeout(() => btn?.classList.remove('ytxt-success'), 1000);
    } catch (err) {
      console.error(err);
      setStatus('Copy failed. Use Ctrl/Cmd+C', 'warn');
    }
  };

  const handleToggleCollapse = () => {
    state.isCollapsed = !state.isCollapsed;
    if (!state.elements) return;

    state.elements.container.classList.toggle('ytxt-collapsed', state.isCollapsed);
    const btn = state.elements.container.querySelector('[data-action="toggle-collapse"]');
    btn.title = state.isCollapsed ? 'Expand panel' : 'Collapse panel';
    btn.setAttribute('aria-label', state.isCollapsed ? 'Expand' : 'Collapse');
  };

  // Responsive panel placement manager

  const SIDEBAR_MIN_WIDTH = 1100;
  const DEBOUNCE_MS = 150;

  let currentMode = null;
  let resizeObserver = null;
  let mutationObserver = null;
  let debounceTimer = null;
  let resizeHandler = null;

  // Debounce helper
  const debounce = (fn, ms) => {
    return (...args) => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => fn(...args), ms);
    };
  };

  // Detect if sidebar is visible
  const isSidebarVisible = () => {
    const sidebar = document.querySelector('#secondary');
    if (!sidebar) return false;

    // Check if actually visible (not display:none, has offsetParent)
    if (sidebar.offsetParent === null) return false;

    const rect = sidebar.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  };

  // Detect best placement mode
  const detectMode = () => {
    const width = window.innerWidth;

    // Check for theater mode
    const flexy = document.querySelector('ytd-watch-flexy');
    const isTheater = flexy?.hasAttribute('theater') || flexy?.getAttribute('theater') === '';

    // Theater mode: prefer Inline for full-width focus
    if (isTheater) return 'inline';

    // Check sidebar visibility and width
    if (isSidebarVisible() && width >= SIDEBAR_MIN_WIDTH) {
      return 'sidebar';
    }

    // Default to inline for everything else
    return 'inline';
  };

  // Find inline insertion point (below player/title, before description)
  const getInlineTarget = () => {
    // Try primary-inner (contains player, title, description)
    const primaryInner = document.querySelector('#primary #primary-inner');
    if (primaryInner) {
      // Insert after title/info, before description
      const below = primaryInner.querySelector('#below');
      if (below) return { parent: primaryInner, before: below };

      // Fallback: just append to primary-inner
      return { parent: primaryInner, before: null };
    }

    // Fallback: use primary
    const primary = document.querySelector('#primary');
    if (primary) return { parent: primary, before: null };

    return null;
  };

  // Attach panel to the appropriate location
  const attachPanel = (panel) => {
    if (!panel) return;

    const mode = detectMode();

    // Already in correct mode and attached
    if (currentMode === mode && panel.parentNode) return;

    // Remove old mode class
    if (currentMode) {
      panel.classList.remove(`ytxt-mode-${currentMode}`);
    }

    // Detach from current location
    if (panel.parentNode) {
      panel.parentNode.removeChild(panel);
    }

    // Attach to new location
    if (mode === 'sidebar') {
      const sidebar = document.querySelector('#secondary');
      if (sidebar) {
        sidebar.prepend(panel);
        panel.classList.add('ytxt-mode-sidebar');
        currentMode = 'sidebar';
      } else {
        // Fallback to inline if sidebar disappeared
        const target = getInlineTarget();
        if (target) {
          if (target.before) {
            target.parent.insertBefore(panel, target.before);
          } else {
            target.parent.appendChild(panel);
          }
          panel.classList.add('ytxt-mode-inline');
          currentMode = 'inline';
        }
      }
    } else {
      // Inline mode
      const target = getInlineTarget();
      if (target) {
        if (target.before) {
          target.parent.insertBefore(panel, target.before);
        } else {
          target.parent.appendChild(panel);
        }
        panel.classList.add('ytxt-mode-inline');
        currentMode = 'inline';
      } else {
        // Last resort: floating
        document.body.appendChild(panel);
        panel.classList.add('ytxt-floating');
        currentMode = 'floating';
      }
    }
  };

  // Start observing for layout changes
  const startObserving = (panel) => {
    if (!panel) return;

    resizeHandler = debounce(() => attachPanel(panel), DEBOUNCE_MS);

    // Observe viewport resize
    resizeObserver = new ResizeObserver(resizeHandler);

    // Watch the watch-flexy container for theater mode changes
    const flexy = document.querySelector('ytd-watch-flexy');
    if (flexy) {
      resizeObserver.observe(flexy);
    }

    // Watch for sidebar visibility changes
    mutationObserver = new MutationObserver(resizeHandler);

    const columns = document.querySelector('#columns');
    if (columns) {
      mutationObserver.observe(columns, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['style', 'hidden', 'theater']
      });
    }

    // Also watch document for theater attribute changes
    if (flexy) {
      mutationObserver.observe(flexy, {
        attributes: true,
        attributeFilter: ['theater']
      });
    }

    // Watch for window resize
    window.addEventListener('resize', resizeHandler);
  };

  // Stop observing
  const stopObserving = () => {
    if (resizeObserver) {
      resizeObserver.disconnect();
      resizeObserver = null;
    }

    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }

    if (resizeHandler) {
      window.removeEventListener('resize', resizeHandler);
      resizeHandler = null;
    }

    clearTimeout(debounceTimer);
    currentMode = null;
  };

  // Reset placement (useful on navigation)
  const resetPlacement = () => {
    currentMode = null;
  };

  // UI panel creation and rendering


  const PANEL_ID = 'ytxt-panel';

  // Helper to safely set innerHTML with TrustedHTML support
  let trustedHTMLPolicy = null;
  const setTrustedHTML = (element, htmlString) => {
    if (window.trustedTypes && trustedTypes.createPolicy) {
      if (!trustedHTMLPolicy) {
        trustedHTMLPolicy = trustedTypes.createPolicy('ytxt-html', {
          createHTML: (string) => string
        });
      }
      element.innerHTML = trustedHTMLPolicy.createHTML(htmlString);
    } else {
      element.innerHTML = htmlString;
    }
  };

  // Parse timestamp from line, supports [HH:MM:SS] and [MM:SS] formats
  const parseTimestamp = (line) => {
    // Try [HH:MM:SS] format first
    let match = line.match(/^\[(\d{1,2}):(\d{2}):(\d{2})\]/);
    if (match) {
      const hours = parseInt(match[1], 10);
      const minutes = parseInt(match[2], 10);
      const seconds = parseInt(match[3], 10);
      return hours * 3600 + minutes * 60 + seconds;
    }
    // Try [MM:SS] format
    match = line.match(/^\[(\d{1,2}):(\d{2})\]/);
    if (match) {
      const minutes = parseInt(match[1], 10);
      const seconds = parseInt(match[2], 10);
      return minutes * 60 + seconds;
    }
    return null;
  };

  // Switch between text and chips view
  const switchView = (view, save = true) => {
    if (!state.elements) return;

    state.currentView = view;
    if (save) {
      localStorage.setItem('ytxt-view', view);
    }

    // Update button states
    state.elements.container.querySelectorAll('[data-view]').forEach(btn => {
      btn.classList.toggle('ytxt-view-btn-active', btn.dataset.view === view);
    });

    // Show/hide views
    if (view === 'text') {
      state.elements.viewText.style.display = '';
      state.elements.viewChips.style.display = 'none';
    } else {
      state.elements.viewText.style.display = 'none';
      state.elements.viewChips.style.display = '';
      // Render chips if we have content
      if (state.elements.output.value) {
        renderChips(state.elements.output.value);
      }
    }
  };

  // Render chips from transcript text
  const renderChips = (text, filterQuery = '') => {
    if (!state.elements?.chips) return;

    const lines = text.split('\n').filter(l => l.trim());
    const queryLower = filterQuery.toLowerCase();

    // Clear existing chips
    state.elements.chips.innerHTML = '';

    lines.forEach(line => {
      // Skip lines that don't match filter
      if (filterQuery && !line.toLowerCase().includes(queryLower)) {
        return;
      }

      const chip = document.createElement('button');
      chip.className = 'ytxt-chip';

      // Extract timestamp and text
      const tsMatch = line.match(/^\[(\d{1,2}:\d{2}:\d{2})\]\s*/);
      if (tsMatch) {
        const timestamp = tsMatch[1];
        const content = line.slice(tsMatch[0].length);
        const seconds = parseTimestamp(line);

        // Store timestamp for video sync
        if (seconds !== null) {
          chip.dataset.time = seconds;
        }

        const tsSpan = document.createElement('span');
        tsSpan.className = 'ytxt-chip-time';
        tsSpan.textContent = timestamp;

        const textSpan = document.createElement('span');
        textSpan.className = 'ytxt-chip-text';

        // Highlight search query in text
        if (filterQuery) {
          const parts = content.split(new RegExp(`(${escapeRegex(filterQuery)})`, 'gi'));
          parts.forEach(part => {
            if (part.toLowerCase() === queryLower) {
              const mark = document.createElement('mark');
              mark.className = 'ytxt-highlight';
              mark.textContent = part;
              textSpan.appendChild(mark);
            } else {
              textSpan.appendChild(document.createTextNode(part));
            }
          });
        } else {
          textSpan.textContent = content;
        }

        chip.appendChild(tsSpan);
        chip.appendChild(textSpan);

        // Click to seek
        chip.addEventListener('click', () => {
          if (seconds !== null) {
            const video = document.querySelector('video');
            if (video) {
              video.currentTime = seconds;
              if (video.paused) video.play();
            }
          }
        });
      } else {
        // No timestamp - just show text
        chip.textContent = line;
      }

      state.elements.chips.appendChild(chip);
    });

    // Start video sync after rendering chips
    startVideoSync();
  };

  // Video sync - highlight active chip based on video position
  let videoSyncHandler = null;
  let lastActiveChip = null;

  const startVideoSync = () => {
    const video = document.querySelector('video');
    if (!video) return;

    // Remove old listener if exists
    if (videoSyncHandler) {
      video.removeEventListener('timeupdate', videoSyncHandler);
    }

    videoSyncHandler = () => {
      if (state.currentView !== 'chips' || !state.elements?.chips) return;

      const currentTime = video.currentTime;
      const chips = state.elements.chips.querySelectorAll('.ytxt-chip[data-time]');

      let activeChip = null;
      let activeTime = -1;

      // Find the chip with the largest timestamp <= currentTime
      chips.forEach(chip => {
        const chipTime = parseFloat(chip.dataset.time);
        if (chipTime <= currentTime && chipTime > activeTime) {
          activeTime = chipTime;
          activeChip = chip;
        }
      });

      // Update active state
      if (activeChip !== lastActiveChip) {
        if (lastActiveChip) {
          lastActiveChip.classList.remove('ytxt-chip-active');
        }
        if (activeChip) {
          activeChip.classList.add('ytxt-chip-active');
          // Scroll into view (smooth, centered)
          activeChip.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        lastActiveChip = activeChip;
      }
    };

    video.addEventListener('timeupdate', videoSyncHandler);
  };

  const stopVideoSync = () => {
    const video = document.querySelector('video');
    if (video && videoSyncHandler) {
      video.removeEventListener('timeupdate', videoSyncHandler);
      videoSyncHandler = null;
    }
    lastActiveChip = null;
  };

  // Helper to escape regex special chars
  const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const createPanel = () => {
    if (document.getElementById(PANEL_ID)) return document.getElementById(PANEL_ID);

    const container = document.createElement('div');
    container.id = PANEL_ID;
    container.className = 'ytxt-panel';

    const panelHTML = `
    <div class="ytxt-header">
      <div class="ytxt-title">
        <svg class="ytxt-icon" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M2 3h12v2H2V3zm0 4h12v2H2V7zm0 4h8v2H2v-2z"/>
        </svg>
        Transcript
      </div>
      <div class="ytxt-tools">
        <label class="ytxt-toggle" title="Include timestamps">
          <input type="checkbox" id="ytxt-timestamps" checked />
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 1a7 7 0 100 14A7 7 0 008 1zm0 12.5A5.5 5.5 0 118 2.5a5.5 5.5 0 010 11zM8 4v4.5l3 1.5-.6 1.1L6.5 9V4H8z"/>
          </svg>
        </label>
        <label class="ytxt-toggle" title="Auto-load transcript when page loads">
          <input type="checkbox" id="ytxt-autoload" />
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 3a5 5 0 104.546 2.914.5.5 0 01.908-.417A6 6 0 118 2v1z"/>
            <path d="M8 4.466V.534a.25.25 0 01.41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 018 4.466z"/>
          </svg>
        </label>
        <button class="ytxt-btn ytxt-icon-btn ytxt-collapse-btn" data-action="toggle-collapse" title="Collapse panel" aria-label="Collapse">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 10l-4-4h8l-4 4z"/>
          </svg>
        </button>
      </div>
    </div>

    <div class="ytxt-body">
      <div class="ytxt-row">
        <select id="ytxt-track" class="ytxt-select" title="Select caption track" aria-label="Caption track"></select>
        <button class="ytxt-cta" data-action="fetch">
          <span class="ytxt-btn-text">Get Transcript</span>
          <span class="ytxt-spinner" style="display: none;"></span>
        </button>
      </div>

      <div class="ytxt-output-wrapper" style="display: none;">
        <div class="ytxt-view ytxt-view-text">
          <textarea id="ytxt-output" class="ytxt-output" rows="16" placeholder="Select a track and click 'Get Transcript' to load subtitles..." spellcheck="false" aria-label="Transcript output"></textarea>
          <div class="ytxt-results" id="ytxt-results" style="display: none;"></div>
        </div>
        <div class="ytxt-view ytxt-view-chips" style="display: none;">
          <div class="ytxt-chips" id="ytxt-chips"></div>
        </div>

        <div class="ytxt-toolbar">
          <div class="ytxt-search-wrapper">
            <svg class="ytxt-search-icon" width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
              <path d="M11.742 10.344a6.5 6.5 0 10-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 001.415-1.414l-3.85-3.85a1.007 1.007 0 00-.115-.1zM12 6.5a5.5 5.5 0 11-11 0 5.5 5.5 0 0111 0z"/>
            </svg>
            <input type="text" id="ytxt-search" class="ytxt-search" placeholder="Search..." aria-label="Search" />
            <span class="ytxt-search-count" id="ytxt-search-count"></span>
            <button class="ytxt-btn ytxt-icon-btn ytxt-search-clear" data-action="clear-search" title="Clear search" aria-label="Clear search" style="display: none;">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                <path d="M8 0a8 8 0 100 16A8 8 0 008 0zM5.354 4.646L8 7.293l2.646-2.647a.5.5 0 01.708.708L8.707 8l2.647 2.646a.5.5 0 01-.708.708L8 8.707l-2.646 2.647a.5.5 0 01-.708-.708L7.293 8 4.646 5.354a.5.5 0 01.708-.708z"/>
              </svg>
            </button>
          </div>
          <div class="ytxt-view-switcher">
            <button class="ytxt-view-btn ytxt-view-btn-active" data-view="text" title="Text view">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                <path d="M2 3h12v2H2V3zm0 4h12v2H2V7zm0 4h8v2H2v-2z"/>
              </svg>
            </button>
            <button class="ytxt-view-btn" data-view="chips" title="Timeline view">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                <path d="M1 4a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1H2a1 1 0 01-1-1V4zm5 0a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1H7a1 1 0 01-1-1V4zm5 0a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1V4zM1 9a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1H2a1 1 0 01-1-1V9zm5 0a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1H7a1 1 0 01-1-1V9z"/>
              </svg>
            </button>
          </div>
          <div class="ytxt-actions">
            <button class="ytxt-btn ytxt-icon-btn" data-action="copy-filtered" title="Copy filtered results" aria-label="Copy filtered" style="display: none;">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                <path d="M1.5 1.5A.5.5 0 012 1h12a.5.5 0 01.5.5v2a.5.5 0 01-.128.334L10 8.692V13.5a.5.5 0 01-.342.474l-3 1A.5.5 0 016 14.5V8.692L1.628 3.834A.5.5 0 011.5 3.5v-2z"/>
              </svg>
            </button>
            <button class="ytxt-btn ytxt-text-btn" data-action="copy" title="Copy to clipboard (Ctrl+Shift+C)">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                <path d="M4 2a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2H6a2 2 0 01-2-2V2zm2-1a1 1 0 00-1 1v8a1 1 0 001 1h8a1 1 0 001-1V2a1 1 0 00-1-1H6zM2 5a1 1 0 00-1 1v8a1 1 0 001 1h8a1 1 0 001-1v-1h1v1a2 2 0 01-2 2H2a2 2 0 01-2-2V6a2 2 0 012-2h1v1H2z"/>
              </svg>
              Copy
            </button>
            <button class="ytxt-btn ytxt-text-btn" data-action="download" title="Download as .txt">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                <path d="M8 12l-4-4h2.5V3h3v5H12l-4 4zm-6 1h12v2H2v-2z"/>
              </svg>
              Save
            </button>
          </div>
        </div>
      </div>
        <div class="ytxt-empty-state" style="display: none;">
          <svg width="48" height="48" viewBox="0 0 16 16" fill="currentColor" opacity="0.3">
            <path d="M2 3h12v2H2V3zm0 4h12v2H2V7zm0 4h8v2H2v-2z"/>
          </svg>
          <p>No transcript loaded yet</p>
        </div>
      </div>

      <div class="ytxt-footer">
        <div class="ytxt-footnote" id="ytxt-status"></div>
        <div class="ytxt-stats" id="ytxt-stats"></div>
        <div class="ytxt-debug">
          <details id="ytxt-debug-details">
            <summary title="Show debug info">Debug</summary>
            <pre id="ytxt-debug-pre" class="ytxt-debug-pre" aria-label="Debug info"></pre>
          </details>
        </div>
      </div>
    </div>
  `;

    setTrustedHTML(container, panelHTML);

    // Use placement manager for responsive positioning
    attachPanel(container);
    startObserving(container);

    // Cache elements
    state.elements = {
      container,
      sel: container.querySelector('#ytxt-track'),
      btnGet: container.querySelector('[data-action="fetch"]'),
      outputWrapper: container.querySelector('.ytxt-output-wrapper'),
      output: container.querySelector('#ytxt-output'),
      results: container.querySelector('#ytxt-results'),
      viewText: container.querySelector('.ytxt-view-text'),
      viewChips: container.querySelector('.ytxt-view-chips'),
      chips: container.querySelector('#ytxt-chips'),
      chkTS: container.querySelector('#ytxt-timestamps'),
      chkAutoload: container.querySelector('#ytxt-autoload'),
      searchInput: container.querySelector('#ytxt-search'),
      searchCount: container.querySelector('#ytxt-search-count'),
      searchClear: container.querySelector('[data-action="clear-search"]'),
      btnCopyFiltered: container.querySelector('[data-action="copy-filtered"]'),
      status: container.querySelector('#ytxt-status'),
      stats: container.querySelector('#ytxt-stats'),
      body: container.querySelector('.ytxt-body'),
      spinner: container.querySelector('.ytxt-spinner'),
      btnText: container.querySelector('.ytxt-btn-text')
    };

    // Current view state
    state.currentView = localStorage.getItem('ytxt-view') || 'text';

    // Event delegation
    container.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;

      const action = btn.dataset.action;
      if (action === 'fetch') {
        await handleFetch();
      } else if (action === 'copy') {
        await handleCopy();
      } else if (action === 'copy-plain') {
        await handleCopyPlain();
      } else if (action === 'copy-filtered') {
        await handleCopyFiltered();
      } else if (action === 'download') {
        handleDownload();
      } else if (action === 'toggle-collapse') {
        handleToggleCollapse();
      }
    });

    // View switcher
    container.querySelectorAll('[data-view]').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.dataset.view;
        switchView(view);
      });
    });

    // Initialize view from saved preference
    if (state.currentView === 'chips') {
      switchView('chips', false);
    }

    // Search functionality - works on both text and chips view
    if (state.elements.searchInput) {
      state.elements.searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim();
        const text = state.elements.output.value;

        // Count matches for display
        const queryLower = query.toLowerCase();
        const lines = text.split('\n');
        const matches = query ? lines.filter(line => line.toLowerCase().includes(queryLower)) : [];

        // Update count and buttons
        state.elements.searchCount.textContent = query ? `${matches.length}` : '';
        state.elements.searchClear.style.display = query ? '' : 'none';
        state.elements.btnCopyFiltered.style.display = matches.length > 0 ? '' : 'none';

        // Handle chips view filtering
        if (state.currentView === 'chips') {
          renderChips(text, query);
          return;
        }

        // Handle text view filtering
        if (!query) {
          // No search - show full textarea
          state.elements.output.style.display = '';
          state.elements.results.style.display = 'none';
          return;
        }

        // Render filtered results in text view
        if (matches.length > 0) {
          state.elements.output.style.display = 'none';
          state.elements.results.style.display = '';

          // Clear and rebuild results
          state.elements.results.innerHTML = '';

          matches.forEach(line => {
            const lineEl = document.createElement('div');
            lineEl.className = 'ytxt-result-line';

            // Highlight search term
            const parts = line.split(new RegExp(`(${escapeRegex(query)})`, 'gi'));
            parts.forEach(part => {
              if (part.toLowerCase() === queryLower) {
                const mark = document.createElement('mark');
                mark.className = 'ytxt-highlight';
                mark.textContent = part;
                lineEl.appendChild(mark);
              } else {
                lineEl.appendChild(document.createTextNode(part));
              }
            });

            // Make clickable for timestamp seeking
            lineEl.addEventListener('click', () => {
              const totalSeconds = parseTimestamp(line);
              if (totalSeconds !== null) {
                const video = document.querySelector('video');
                if (video) {
                  video.currentTime = totalSeconds;
                  if (video.paused) video.play();
                }
              }
            });

            state.elements.results.appendChild(lineEl);
          });
        } else {
          // No matches - show empty state in results
          state.elements.output.style.display = 'none';
          state.elements.results.style.display = '';
          state.elements.results.innerHTML = '<div class="ytxt-no-results">No matches found</div>';
        }
      });
    }

    // Clear search button
    if (state.elements.searchClear) {
      state.elements.searchClear.addEventListener('click', () => {
        if (state.elements.searchInput) {
          state.elements.searchInput.value = '';
          state.elements.searchInput.dispatchEvent(new Event('input'));
        }
      });
    }

    // Helper to escape regex special chars
    const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    // Auto-load preference
    if (state.elements.chkAutoload) {
      // Load saved preference
      const savedAutoload = localStorage.getItem('ytxt-autoload');
      if (savedAutoload === 'true') {
        state.elements.chkAutoload.checked = true;
      }

      // Save preference on change
      state.elements.chkAutoload.addEventListener('change', (e) => {
        localStorage.setItem('ytxt-autoload', e.target.checked);
      });
    }

    // Clickable timestamps to seek video
    if (state.elements.output) {
      state.elements.output.addEventListener('click', (e) => {
        const textarea = e.target;
        const cursorPos = textarea.selectionStart;
        const text = textarea.value;

        // Find the line containing the cursor
        const lineStart = text.lastIndexOf('\n', cursorPos - 1) + 1;
        const lineEnd = text.indexOf('\n', cursorPos);
        const line = text.substring(lineStart, lineEnd === -1 ? text.length : lineEnd);

        const totalSeconds = parseTimestamp(line);
        if (totalSeconds !== null) {
          const video = document.querySelector('video');
          if (video) {
            video.currentTime = totalSeconds;
            if (video.paused) video.play();
          }
        }
      });
    }

    updateTrackSelect(state.tracks);
    return container;
  };

  const destroyPanel = () => {
    stopObserving();
    stopVideoSync();
    const el = document.getElementById(PANEL_ID);
    if (el?.parentNode) el.parentNode.removeChild(el);
  };

  // Listen for transcript loaded event to update chips view
  window.addEventListener('ytxt:transcript-loaded', (e) => {
    try {
      if (state.currentView === 'chips' && e?.detail?.text) {
        renderChips(e.detail.text);
      }
    } catch {}
  });

  // Main entry point for YouTube Transcript extension


  // --- Lifecycle ----------------------------------------------------------
  let autoloadTimer = null;
  let initTimer = null;

  // Check if an ad is currently playing
  const isAdPlaying = () => {
    const player = document.querySelector('.html5-video-player');
    return player?.classList.contains('ad-showing') || false;
  };

  const updateCaptions = () => {
    const data = extractCaptionTracks();
    state.tracks = data.tracks || [];
    state.videoId = data.videoId || null;

    if (state.elements) {
      updateTrackSelect(state.tracks);

      // Auto-load if enabled (but not during ads)
      const autoloadEnabled = localStorage.getItem('ytxt-autoload') === 'true';
      if (autoloadEnabled && state.tracks?.length > 0 && !state.elements.output.value && !isAdPlaying()) {
        // Small delay to ensure UI is ready, but cancel if navigating
        clearTimeout(autoloadTimer);
        autoloadTimer = setTimeout(() => {
          if (state.elements && !isAdPlaying()) handleFetch();
        }, 500);
      }
    }
  };

  const onNavigate = () => {
    // Clear pending timers to prevent race conditions
    clearTimeout(autoloadTimer);
    clearTimeout(initTimer);

    state.tracks = [];
    state.videoId = null;
    state.elements = null;

    destroyPanel();
    resetPlacement();
    createPanel();
    updateCaptions();
  };

  // --- Init ---------------------------------------------------------------
  // Install page-context observer and bridge harvested templates
  injectObserver();
  window.addEventListener('ytxt:transcript-template', (e) => {
    try { onHarvestEvent(e.detail); } catch {}
  });
  window.addEventListener('yt-navigate-finish', onNavigate);
  window.addEventListener('yt-page-data-updated', updateCaptions);

  // Singleton keyboard shortcut (registered once, never removed)
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
      e.preventDefault();
      handleCopy();
    }
  });

  // PlacementManager now handles layout changes automatically via its observers

  // Watch for ad state changes to refresh captions when ad finishes
  let wasAdPlaying = false;
  const adObserver = new MutationObserver(() => {
    const adNow = isAdPlaying();
    if (wasAdPlaying && !adNow) {
      // Ad just finished - refresh captions after a short delay
      setTimeout(updateCaptions, 1500);
    }
    wasAdPlaying = adNow;
  });

  // Start observing the player for ad class changes
  const startAdObserver = () => {
    const player = document.querySelector('.html5-video-player');
    if (player) {
      adObserver.observe(player, { attributes: true, attributeFilter: ['class'] });
      wasAdPlaying = isAdPlaying();
    }
  };

  // Initial mount
  createPanel();
  initTimer = setTimeout(() => {
    updateCaptions();
    startAdObserver();
  }, 1000);

})();
